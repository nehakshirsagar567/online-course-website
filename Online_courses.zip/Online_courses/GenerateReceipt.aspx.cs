﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace Online_courses
{
    public partial class GenerateReceipt : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the purchaseId parameter exists in the URL
                if (Request.QueryString["purchase_id"] != null)
                {
                    // Retrieve the value of purchaseId parameter from the URL
                    string purchaseId = Request.QueryString["purchase_id"];
                    viewReceipt(purchaseId);
                    //Response.Write("<script type='text/javascript'> alert ('Test " + purchaseId + " Alert'); </script>");

                }

            }
        }

        protected void viewReceipt(String purchaseId) 
        {

            try
            {
                cn.Close();
                cn.Open();
                string query = "select p.*,u.user_name from purchase_course p left join user_signup u on p.user_id=u.user_id where p.purchase_id='" + purchaseId + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    span_purchase_id.InnerText = dr[0].ToString();
                    span_user_name.InnerText = dr[8].ToString();
                    span_course_name.InnerText = dr[3].ToString();
                    span_course_time.InnerText = dr[4].ToString();
                    span_course_price.InnerText = dr[5].ToString();
                    span_purchase_date.InnerText = dr[7].ToString();
                }
                else
                {
                    Response.Write("<script type='text/javascript'> alert ('Receipt loading failed');</script>");
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }
    }
}