﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace Online_courses
{
    public partial class cvideo : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
             
                MySqlCommand cmd = new MySqlCommand("select * from addvideo where course_name = '" + Session["course_name"] + "'", cn);
                MySqlDataAdapter Adpt = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                Adpt.Fill(dt);
                //DataList1.DataSource = dt;
                //DataList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string coursename = Session["course_name"].ToString();
             

            try
            {
                cn.Close();
                cn.Open();
                string query = "select * from addpdf where course_name = '" + coursename + "'  ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {                    
                    Response.Write("<script type='text/javascript'> location='pdf/"+dr[3].ToString()+"'; </script>");
                }
                else
                {
                    Response.Write("<script type='text/javascript'> alert ('PDF not found'); location='user_login.aspx'</script>");
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
  
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("cq1.aspx");
        }
      
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("close.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("videos.aspx");
        }

        
    }
}