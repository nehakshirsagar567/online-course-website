create database Online_courses;

use Online_courses;

create table user_signup
(
 user_id int primary key auto_increment,
 user_name nvarchar(50),
 email_id nvarchar(50),
 password nvarchar(50),
 reset_token nvarchar(50)
);

create table addcoursedata
(
data_id int primary key auto_increment,
course_id nvarchar(50),
course_name nvarchar(50),
Description nvarchar(900),
created_by nvarchar(50),
price nvarchar(50),
whatyouwilllearn nvarchar(900)
);

create table addcourses
(
course_id int auto_increment primary key,
course_name nvarchar(50),
course_time nvarchar(50),
course_price nvarchar(50),
course_image nvarchar(100)
);

create table addpdf
(
pdf_id int primary key auto_increment,
course_id nvarchar(50),
course_name nvarchar(50),
pdf_name nvarchar(50)
);

create table addquize
(
quize_id int primary key auto_increment,
course_id int,
course_name nvarchar(50),
question_no nvarchar(50),
question nvarchar(200),
option1 nvarchar(150),
option2 nvarchar(150),
option3 nvarchar(150),
option4 nvarchar(150),
Correct_Answer nvarchar(150)
);

create table addvideo
(
video_id int primary key auto_increment,
course_id nvarchar(50),
course_name nvarchar(50),
video_title nvarchar(50),
video nvarchar(200)
);

CREATE TABLE adminsignup (
  admin_id int auto_increment primary key,
  user_name nvarchar(50),
  email_id nvarchar(50),
  password nvarchar(50)  
);


 create table contactus
 (
 contact_id int primary key auto_increment,
 name nvarchar(50),
 email nvarchar(50),
 message nvarchar(80)
 );
 
 create table payment
 (
 payment_id int primary key auto_increment,
 user_id int,
 amount nvarchar(50),
 card_number nvarchar(50),
 card_holder nvarchar(50),
 cvv nvarchar(50),
 payment_date nvarchar(50)
 );
 
 
 
 create table feedback
 (
 feedback int auto_increment primary key, 
 name nvarchar(50),
 email nvarchar(50),
 feedback_category nvarchar(100),
 message nvarchar(100)
 );
 
 create table purchase_course
 (
	purchase_id int auto_increment primary key,
    user_id int,
    course_id int,
	course_name nvarchar(50),
	course_time nvarchar(50),
	course_price nvarchar(50),
	course_image nvarchar(100),
	purchase_date nvarchar(50)
    
 );
  
  create table result
  (
  result_id int auto_increment primary key,
  user_id int,
  user_name nvarchar(70),
  course_name nvarchar(70),
  solved_questions nvarchar(70),
  total_questions nvarchar(70),
  correct_questions nvarchar(70),
  marks_obtained nvarchar(70)
  );
  





