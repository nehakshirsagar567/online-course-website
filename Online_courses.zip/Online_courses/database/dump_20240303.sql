-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: online_courses
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addcoursedata`
--

DROP TABLE IF EXISTS `addcoursedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addcoursedata` (
  `data_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(50) DEFAULT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `Description` varchar(900) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `whatyouwilllearn` varchar(900) DEFAULT NULL,
  PRIMARY KEY (`data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addcoursedata`
--

LOCK TABLES `addcoursedata` WRITE;
/*!40000 ALTER TABLE `addcoursedata` DISABLE KEYS */;
INSERT INTO `addcoursedata` VALUES (1,'1','C for begginers','c is general purpose computer pogramming language.it is mother of all programming languages.','Prathamesh Kirmate','Rs-4000','data types\r\noprators'),(2,'2','java for beginers','java is one of the best programming language.it is object oriented programming language','Prathamesh Kirmate','Rs-4000','basic concepts of java.operators in java.data types in java.'),(3,'3','python for begginers','it is siple language.easy to learn','Prathamesh Kirmate','Rs-4000','data types,operators.basic concepts of python'),(4,'4','python for begginers','Python is a object oriented Language which is easy to learn','Prathamesh Kirmate','Rs-4000','Java\r\npython\r\nc');
/*!40000 ALTER TABLE `addcoursedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addcourses`
--

DROP TABLE IF EXISTS `addcourses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addcourses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(50) DEFAULT NULL,
  `course_time` varchar(50) DEFAULT NULL,
  `course_price` varchar(50) DEFAULT NULL,
  `course_image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addcourses`
--

LOCK TABLES `addcourses` WRITE;
/*!40000 ALTER TABLE `addcourses` DISABLE KEYS */;
INSERT INTO `addcourses` VALUES (1,'C for biginners','2 months',' Rs-4000','c.png'),(2,'C++ for biginners','2 months','Rs-4000','cpp.png'),(3,'Java for biginners','3 months','Rs-4000','java.png'),(4,'Python for biginners','6 Months','Rs-4000','python.png');
/*!40000 ALTER TABLE `addcourses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addpdf`
--

DROP TABLE IF EXISTS `addpdf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addpdf` (
  `pdf_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(50) DEFAULT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `pdf_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pdf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addpdf`
--

LOCK TABLES `addpdf` WRITE;
/*!40000 ALTER TABLE `addpdf` DISABLE KEYS */;
INSERT INTO `addpdf` VALUES (1,'1','C for biginners','C programming.pdf'),(2,'2','C++ for beginners','C++.notes.pdf'),(3,'3','java for beginers','C programming.pdf'),(4,'4','python for begginers','Javanotes.pdf');
/*!40000 ALTER TABLE `addpdf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addquize`
--

DROP TABLE IF EXISTS `addquize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addquize` (
  `quize_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `question_no` varchar(50) DEFAULT NULL,
  `question` varchar(50) DEFAULT NULL,
  `option1` varchar(50) DEFAULT NULL,
  `option2` varchar(50) DEFAULT NULL,
  `option3` varchar(50) DEFAULT NULL,
  `option4` varchar(50) DEFAULT NULL,
  `Correct_Answer` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`quize_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addquize`
--

LOCK TABLES `addquize` WRITE;
/*!40000 ALTER TABLE `addquize` DISABLE KEYS */;
INSERT INTO `addquize` VALUES (1,1,'C for biginners','1','Who is father of C language? ','Dennis Ritchie','Steve Jobs','James Gosling','Rasmus Lerdorf','Dennis Ritchie'),(2,1,'C for biginners','2','All keywords in C are in?','Upper Case letters','Lower Case letters','Camel Case letters','None of the mentioned','Lower Case letters'),(3,1,'C for biginners','3','C is a.....?','Low level language','High level language','Medium level language','None of the above','Medium level language'),(4,1,'C for biginners','4','how many keywords are there in C language?','32','33','60','21','32'),(5,1,'C for biginners','5','In C language,FILE is of which data type?','int','char*','struct','None of the mentioned','struct'),(6,2,'C++ for biginners','1','hgsuh jhgrugh  jsjhg','abc','xyz','pqr','hij','abc');
/*!40000 ALTER TABLE `addquize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addvideo`
--

DROP TABLE IF EXISTS `addvideo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addvideo` (
  `video_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(50) DEFAULT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `video` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addvideo`
--

LOCK TABLES `addvideo` WRITE;
/*!40000 ALTER TABLE `addvideo` DISABLE KEYS */;
INSERT INTO `addvideo` VALUES (2,'2','C++ for beginners','C++1.mp4');
/*!40000 ALTER TABLE `addvideo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminsignup`
--

DROP TABLE IF EXISTS `adminsignup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminsignup` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminsignup`
--

LOCK TABLES `adminsignup` WRITE;
/*!40000 ALTER TABLE `adminsignup` DISABLE KEYS */;
INSERT INTO `adminsignup` VALUES (1,'neha','nehakshisagar567@gmail.com','12345'),(2,'neha','nehakshisagar567@gmail.com','1234'),(3,'neha','nehakshisagar567@gmail.com','123456'),(4,'abc','abc@gmail.com','12345678'),(5,'abc','abc@gmail.com','12345678'),(6,'neha','abc@gmail.com','1234'),(7,'bruno','bruno123@gmail.com','1234'),(8,'admin','admin@gmail.com','12345678'),(9,'newadmin','newadmin@gmail.com','12345678'),(10,'admin3','admin3@gmail.com','12345678'),(11,'Neha','abc123@gmail.com','12345678');
/*!40000 ALTER TABLE `adminsignup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactus`
--

DROP TABLE IF EXISTS `contactus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactus` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `message` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactus`
--

LOCK TABLES `contactus` WRITE;
/*!40000 ALTER TABLE `contactus` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `feedback` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `feedback_category` varchar(100) DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`feedback`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `card_number` varchar(50) DEFAULT NULL,
  `card_holder` varchar(50) DEFAULT NULL,
  `cvv` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (16,1,' Rs-4000','1234','neha','1121'),(17,1,'Rs-4000','1234','neha','1121');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_course`
--

DROP TABLE IF EXISTS `purchase_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_course` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `course_time` varchar(50) DEFAULT NULL,
  `course_price` varchar(50) DEFAULT NULL,
  `course_image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_course`
--

LOCK TABLES `purchase_course` WRITE;
/*!40000 ALTER TABLE `purchase_course` DISABLE KEYS */;
INSERT INTO `purchase_course` VALUES (16,1,1,'C for biginners','2 months',' Rs-4000','c.png'),(17,1,2,'C++ for biginners','2 months','Rs-4000','cpp.png');
/*!40000 ALTER TABLE `purchase_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result` (
  `result_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(70) DEFAULT NULL,
  `course_name` varchar(70) DEFAULT NULL,
  `solved_questions` varchar(70) DEFAULT NULL,
  `total_questions` varchar(70) DEFAULT NULL,
  `correct_questions` varchar(70) DEFAULT NULL,
  `marks_obtained` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`result_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` VALUES (1,1,'','C for biginners','1','-1','1','1'),(2,1,'vishal','C for biginners','0','-2','0','0'),(3,1,'vishal','C for biginners','5','5','1','1');
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_signup`
--

DROP TABLE IF EXISTS `user_signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_signup` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_signup`
--

LOCK TABLES `user_signup` WRITE;
/*!40000 ALTER TABLE `user_signup` DISABLE KEYS */;
INSERT INTO `user_signup` VALUES (1,'vishal','vishal@gmail.com','12345678'),(2,'test','test@gmail.com','test@123'),(3,'vishal','','12345678'),(4,'vishal','abc123@gmail.com','12345678'),(5,'vishal','abc123@gmail.com','12345678');
/*!40000 ALTER TABLE `user_signup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-03 18:13:34
