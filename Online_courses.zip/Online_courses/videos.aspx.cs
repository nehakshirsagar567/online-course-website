﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace Online_courses
{
    public partial class videos : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && Session["course_name"] != null)
            {
                String courseName = Session["course_name"].ToString();
                BindVideos(courseName);
            }
        }

        private void BindVideos(String courseName)
        {
            //Response.Write("<script type='text/javascript'> alert('" + courseName + "test" + "'); </script>");

            cn.Close();
            cn.Open();

            string query = "SELECT * FROM addvideo WHERE course_name = '"+courseName+"'";
            MySqlCommand cmd = new MySqlCommand(query, cn);
            cmd.Parameters.AddWithValue("@courseName", courseName);

            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);

            rptVideos.DataSource = dt;
            rptVideos.DataBind();

            cn.Close();
        }
        protected void lnkPage_Click(object sender, EventArgs e)
        {
            LinkButton lnkPage = (LinkButton)sender;
            int pageIndex = Convert.ToInt32(lnkPage.CommandArgument);
            Response.Redirect("~/videos.aspx?page=" + pageIndex);
        }
    }
}