﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class addcoursedata : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void button1_Click(object sender, EventArgs e)
        {
            string dataid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string description = Textbox4.Text;
            string createdby = Textbox5.Text;
            string price = Textbox6.Text;
            string whatyouwilllearn = Textbox7.Text;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into addcoursedata (data_id,course_id,course_name,Description,created_by,price,whatyouwilllearn) values( '" + dataid + "', '" + courseid + "' , '" + coursename + "', '" + description + "', '" + createdby + "', '" + price + "', '" + whatyouwilllearn + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information added Successfully'); location='addcoursedata.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addcoursedata.aspx' </script>");
            }            

          
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string dataid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string description = Textbox4.Text;
            string createdby = Textbox5.Text;
            string price = Textbox6.Text;
            string whatyouwilllearn = Textbox7.Text;

            try
            {
                cn.Close();
                cn.Open();
                String query = "update addcoursedata set course_id = '" + courseid + "' , course_name = '" + coursename + "', description = '" + description + "', createdby = '" + createdby + "', whatyouwilllearn = '" + whatyouwilllearn + "' where data_id= '" + dataid + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information Updated Successfully'); location='addcoursedata.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addcoursedata.aspx' </script>");
            } 

        }

        }
    }
