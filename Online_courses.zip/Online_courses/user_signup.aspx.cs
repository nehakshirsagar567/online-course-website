﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class user_signup : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
           // Response.Write("<script type='text/javascript'> alert ('Test Alert'); </script>");
        }

        protected void button_Click(object sender, EventArgs e)
        {           
            String username = txtUsername.Text;
            String email_id = txtEmail.Text;
            String password = txtPassword.Text;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into user_signup(user_name, email_id, password) values('" + username + "', '" + email_id + "', '" + password + "' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('signup Successful'); location='user_login.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Signup Failed, Something went wrong'); 'user_signup.aspx' </script>");
            }            

        }
    }
}