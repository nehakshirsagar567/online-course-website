﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{

    public partial class user_login : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Clear();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            string username = txtUsername.Text;
            string password = txtPassword.Text;

            try
            {
                cn.Close();
                cn.Open();
                string query = "select * from user_signup where user_name = '" + username + "' && password='" + password + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    Session.Clear();
                    Session["user_id"] = dr[0].ToString();
                    Session["user_name"] = dr[1].ToString();
                    //Response.Write("<script type='text/javascript'> alert ('Login successful'); location='User_homepage.aspx'</script>");
                    Response.Redirect("User_homepage.aspx");
                }
                else
                {
                    Response.Write("<script type='text/javascript'> alert ('Login failed'); location='user_login.aspx'</script>");
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }

        }
    }
}
