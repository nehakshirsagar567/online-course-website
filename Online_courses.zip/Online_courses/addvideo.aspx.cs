﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class addvideo : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button1_Click(object sender, EventArgs e)
        {
            string videoid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string videotitle = Textbox4.Text;
            string video = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into addvideo (video_id,course_id,course_name,video_title,video) values( '" + videoid + "', '" + courseid + "' , '" + coursename + "', '" + videotitle + "', '" + video + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information added Successfully'); location='addvideo.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addvideo.aspx' </script>");
            }            

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string videoid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string videotitle = Textbox4.Text;
            string video = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "update addvideo set course_id = '" + courseid + "' , course_name = '" + coursename + "', videotitle = '" + videotitle + "', video = '" + video + "' where video_id= '" + videoid + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information Updated Successfully'); location='addvideo.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }    

        }
    }
}