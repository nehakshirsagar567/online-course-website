﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class payment : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            txtAmount.Text = Session["course_price"].ToString();
        }

        protected void button_Click(object sender, EventArgs e)
        {
            string amount = txtAmount.Text;
            string card_number = txtCardNumber.Text;
            string card_holder = txtCardHolder.Text;
            string cvv = txtCVV.Text;
            string payment_date = DateTime.Today.ToString();

            try
            {
                cn.Close();
                cn.Open();

                string query = "insert into payment(user_id,amount,card_number,card_holder,cvv,payment_date) values('" + Session["user_id"] + "', '" + amount + "','" + card_number + "', '" + card_holder + "', '" + cvv + "', '" + payment_date + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                String query1 = "insert into purchase_course (user_id, course_id, course_name, course_time, course_price, course_image, purchase_date) values ('" + Session["user_id"] + "', '" + Session["course_id"] + "' , '" + Session["course_name"] + "', '" + Session["course_time"] + "' ,'" + Session["course_price"] + "' ,'" + Session["course_image"] + "', '" + payment_date + "')";
                cmd.Connection = cn;
                cmd.CommandText = query1;
                int result1 = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'>alert('Payment Successful'); location = 'Mycourses.aspx'</script>");
                cn.Close();
            }
            catch(Exception ex)
            {
                Response.Write(ex.ToString());
            }

        }
    }
}


















