﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class contactus : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;



        protected void Page_Load(object sender, EventArgs e)
        {

     
        }

        protected void button_Click(object sender, EventArgs e)
        {
            String name = Textbox1.Text;
            String email = Textbox2.Text;
            String message = TextBox3.Text;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into contactus(name, email,message) values('" + name + "', '" + email + "', '" + message + "' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('Information saved Successfully'); location='Main_homepage.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); 'contactus.aspx' </script>");
            }            
        }

    }

}
      