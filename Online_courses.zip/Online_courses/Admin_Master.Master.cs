﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class Admin_Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if the session variable storing user authentication information is null or not present
            if (Session["admin_name"] == null)
            {

                //Redirect the user to the login page
                Response.Redirect("~/adminlogin.aspx");
            }

        }
    }
}