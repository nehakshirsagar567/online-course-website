﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace Online_courses
{
    public partial class Mypayment : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGridView(); // Bind the GridView on initial load
            }
        }

        protected void BindGridView()
        {
            MySqlCommand cmd = new MySqlCommand("select p.*,us.user_name from purchase_course p left join user_signup us on p.user_id=us.user_id where p.user_id = '" + Session["user_id"] + "'", cn);
            //MySqlCommand cmd = new MySqlCommand("select * from payment  where user_id = '" + Session["user_id"] + "'", cn);
            MySqlDataAdapter Adpt = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            Adpt.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void btnViewReceipt_Click(object sender, EventArgs e)
        {

            
            // Get the purchase_id associated with the clicked button
             Button btnViewReceipt = (Button)sender;
             string purchaseId = btnViewReceipt.CommandArgument;
              
             // Redirect to another page passing the purchaseId
             Response.Redirect("GenerateReceipt.aspx?purchase_id="+purchaseId); 
            
            //Response.Write("<script type='text/javascript'> alert ('Test " + purchase_id + "Alert'); </script>");
            
        }
        
    }
}