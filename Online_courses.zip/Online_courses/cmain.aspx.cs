﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class cmain : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                cn.Close();
                cn.Open();
                string query = "select * from addcoursedata where course_id = '" + Session["course_id"].ToString() + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                MySqlDataReader dr = cmd.ExecuteReader();


                if(dr.Read())
                {
                    Label1.Text = dr[2].ToString();
                    Label2.Text = dr[3].ToString();
                    Label3.Text = dr[4].ToString();
                    Label4.Text = dr[5].ToString();
                    Label6.Text = dr[6].ToString();
                    /*Label6.Text = dr[6].ToString();
                   Label7.Text = dr[6].ToString();
                    Label8.Text = dr[6].ToString();
                    Label9.Text = dr[6].ToString();*/
                }
                else
                {
                    Response.Redirect("allcourses2.aspx");
                }

                cn.Close();
            }
            catch (Exception ex)
            { 
                
            }
        }

        protected void button_Click(object sender, EventArgs e)
        {
            Response.Redirect("Payment_proceed.aspx");
        }

      

       
    }
}