﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class forgotps : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
              if (IsPostBack)
            {
                lblToken.Visible = true;
                txtToken.Visible = true;
                lblPassword.Visible = true;
                txtPassword.Visible = true;
                button2.Visible = true;
                button1.Visible = false;
                
            }
        }

        protected void button1_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            Random random = new Random();
            string token = random.Next(100000, 999999).ToString("D6");
            try
            {
                cn.Close();
                cn.Open();
                string query = "Update user_signup SET reset_token='" + token + "' where email_id = '" + email + "'";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {

                    Response.Write("<script type='text/javascript'> alert ('Please check your email id for reset token');</script>");

                }
                else
                {

                    Response.Write("<script type='text/javascript'> alert ('No record found for provided email id'); location='forgotps.aspx' </script>");
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }

        }

        protected void button2_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string token = txtToken.Text;
            string password = txtPassword.Text; ;
            try
            {
                cn.Close();
                cn.Open();
                string query = "Update user_signup SET password='" + password + "' where email_id = '" + email + "' and reset_token='" + token + "'";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {

                    Response.Write("<script type='text/javascript'> alert ('Password reset successfully'); location='user_login.aspx' </script>");
                }
                else
                {

                    Response.Write("<script type='text/javascript'> alert ('Invalid Token Please try again'); location='forgotps.aspx' </script>");
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }

        }
        }
    }
