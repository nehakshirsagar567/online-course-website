﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class close : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_id"] != null && Session["user_name"] != null && Session["course_name"] != null)
            {



                try
                {
                    cn.Close();
                    cn.Open();
                    string query = "select * from result where user_id = '" + Session["user_id"] + "' and course_name = '" + Session["course_name"] + "' and marks_obtained >= 4 ";
                    cmd.Connection = cn;
                    cmd.CommandText = query;
                    int result = cmd.ExecuteNonQuery();
                    MySqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        Label1.Text = Session["user_name"].ToString();
                        Label2.Text = Session["course_name"].ToString();
                        Label3.Text = Convert.ToString(DateTime.Now);
                    }
                    else
                    {
                        Response.Write("<script type='text/javascript'> alert('Please complete quize to get course certificate'); location='cq1.aspx'</script>");
                    }

                    cn.Close();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.ToString());
                }



            }
        }
    }
}