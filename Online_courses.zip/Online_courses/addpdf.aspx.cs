﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class addpdf : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button1_Click(object sender, EventArgs e)
        {
            string pdfid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string pdfname = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into addpdf (pdf_id,course_id,course_name,pdf_name) values( '" + pdfid + "', '" + courseid + "' , '" + coursename + "', '" + pdfname + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information added Successfully'); location='addpdf.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addpdf.aspx' </script>");
            }            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string pdfid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string pdfname = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "update addpdf set course_id = '" + courseid + "' , course_name = '" + coursename + "', pdf_name = '" + pdfname + "' where pdf_id= '" + pdfid + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information Updated Successfully'); location='addcourses.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addpdf.aspx' </script>");
            }            
        }
    }
}