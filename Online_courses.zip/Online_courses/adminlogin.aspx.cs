﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class adminlogin : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Clear();
        }

    

        protected void button_Click1(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            try
            {
                cn.Close();
                cn.Open();
                string query = "select * from adminsignup where user_name = '" + username + "' && password = '" + password + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    Session.Clear();
                    Session["admin_id"] = dr[0].ToString();
                    Session["admin_name"] = dr[1].ToString();
                    Response.Redirect("Admin_homepage.aspx");
                    //Response.Write("<script type='text/javascript'> alert('Login Successful'); location='Admin_homepage.aspx'</script>");
                }
                else
                {
                    Response.Write("<script type='text/javascript'> alert('Login Failed'); location='adminlogin.aspx'</script>");
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }
    }
}