﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class addquize : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button1_Click(object sender, EventArgs e)
        {
            string quizeid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string questionno = Textbox10.Text;
            string question = Textbox4.Text;
            string option1 = Textbox5.Text;
            string option2 = Textbox6.Text;
            string option3 = Textbox7.Text;
            string option4 = Textbox8.Text;
            string CorrectAnswer = Textbox9.Text;
       

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into addquize (quize_id,course_id,course_name, question_no,question,option1,option2,option3,option4,Correct_Answer) values( '" + quizeid + "', '" + courseid + "' , '" + coursename + "', '" + questionno + "', '" + question + "','" + option1 + "','" + option2 + "','" + option3 + "','" + option4 + "','" + CorrectAnswer +"' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information added Successfully'); location='addquize.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addquize.aspx' </script>");
            }            


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string quizeid = Textbox1.Text;
            string courseid = Textbox2.Text;
            string coursename = Textbox3.Text;
            string questionno = Textbox10.Text;
            string question = Textbox4.Text;
            string option1 = Textbox5.Text;
            string option2 = Textbox6.Text;
            string option3 = Textbox7.Text;
            string option4 = Textbox8.Text;
            string CorrectAnswer = Textbox9.Text;
       
            try
            {
                cn.Close();
                cn.Open();
                String query = "update addquize set course_id = '" + courseid + "' , course_name = '" + coursename + "', questionno = '" + questionno + "', question = '" + question + "', option1 = '"+ option1 +"', option2 = '"+ option2 +"', option3 = '"+ option3 +"', option4 = '"+ option4 +"', CorrectAnswer = '"+ CorrectAnswer +"' where quize_id= '" + quizeid + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information Updated Successfully'); location='addcourses.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString()); 
            }    
        }


        }
    }
