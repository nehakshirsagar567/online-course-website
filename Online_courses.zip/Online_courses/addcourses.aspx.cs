﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class addcourses : System.Web.UI.Page
    {
      MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void button_Click1(object sender, EventArgs e)
        {
           // string dataid = Textbox1.Text;
            string courseid = Textbox1.Text;
            string coursename = Textbox2.Text; 
            string coursetime = Textbox3.Text;
            string courseprice = Textbox4.Text;
            string image = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into addcourses (course_id,course_name,course_time,course_price,course_image) values(  '" + courseid + "', '" + coursename + "', '" + coursetime + "' , '" + courseprice + "', '" + image + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information added Successfully'); location='addcourses.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type='text/javascript'> alert('Something went wrong'); location= 'addcourses.aspx' </script>");
            }            

        
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           // string dataid = Textbox1.Text;
            string courseid = Textbox1.Text;
            string coursename = Textbox2.Text;
            string coursetime = Textbox3.Text;
            string courseprice = Textbox4.Text;
            string image = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "update addcourses set course_name = '" + coursename + "' , course_time = '" + coursetime + "', course_price = '" + courseprice + "', course_image = '" + image + "' where course_id= '" + courseid + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<script type='text/javascript'> alert ('information Updated Successfully'); location='addcourses.aspx' </script>");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString()); 
            }    
        }

        
    }
}