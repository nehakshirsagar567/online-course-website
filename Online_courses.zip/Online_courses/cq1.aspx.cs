﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class cq1 : System.Web.UI.Page
 {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=online_courses; user=root; password=root");
     MySqlCommand cmd = new MySqlCommand();
     MySqlDataAdapter da = new MySqlDataAdapter();
     MySqlDataReader dr;


     protected void load_question()
     {
         try
         {
             cn.Close();
             cn.Open();
             //string coursename = Session["course_name"].ToString();
             //Response.Write("<script type='text/javascript'> alert('test " + qno.Value.ToString() +    coursename + "'); </script> ");

             String query = "select * from addquize where course_name='" + Session["course_name"] + "' && question_no='" + qno.Value.ToString() + "'  ";
             cmd.Connection = cn;
             cmd.CommandText = query;
             int result = cmd.ExecuteNonQuery();
             MySqlDataReader dr = cmd.ExecuteReader();

             if (dr.Read())
             {
                 Label4.Text = dr[4].ToString();
                 RadioButton1.Text = dr[5].ToString();
                 RadioButton2.Text = dr[6].ToString();
                 RadioButton3.Text = dr[7].ToString();
                 RadioButton4.Text = dr[8].ToString();

                 HiddenField1.Value = dr[9].ToString();

             }
             else
             {
                 int valqno = Convert.ToInt32(qno.Value.ToString());
                 valqno--;
                 qno.Value = valqno.ToString();
                 //Response.Write("<script type='text/javascript'> alert('" + qno.Value.ToString() + "'); </script> ");
             }
             cn.Close();
         }
         catch (Exception ex)
         {
             Response.Write(ex.ToString());
         }
     }

     
        protected void Page_Load(object sender, EventArgs e)
        {
            //load_question();
            if (!IsPostBack)
            {
                qno.Value = "1";
                marks.Value = "0";
                solved_questions.Value = "0";
                correct_questions.Value = "0"; 

                load_question();
            }
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        { 
                your_ans.Value = RadioButton1.Text.ToString();
                RadioButton2.Checked = false;
                RadioButton3.Checked = false;
                RadioButton4.Checked = false;
        
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        { 
                your_ans.Value = RadioButton2.Text.ToString();
                RadioButton1.Checked = false;
                RadioButton3.Checked = false;
                RadioButton4.Checked = false;
          
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        { 
                your_ans.Value = RadioButton3.Text.ToString();
                RadioButton1.Checked = false;
                RadioButton2.Checked = false;
                RadioButton4.Checked = false;
            
        }

        protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
        { 
                your_ans.Value = RadioButton4.Text.ToString();
                RadioButton1.Checked = false;
                RadioButton2.Checked = false;
                RadioButton3.Checked = false;
          
              
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int valqno = Convert.ToInt32(qno.Value.ToString());
            valqno--;  
            qno.Value = valqno.ToString();
            load_question();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int valqno = Convert.ToInt32(qno.Value.ToString());
            valqno++;
            qno.Value = valqno.ToString();
            load_question(); 
        }

        protected void Button1_Click(object sender, EventArgs e) //submit
        {
            String correct_ans = HiddenField1.Value.ToString();
            int valqno = Convert.ToInt32(qno.Value.ToString());
            int valmarks = Convert.ToInt32(marks.Value.ToString());
            int valsolved_questions = Convert.ToInt32(solved_questions.Value.ToString());
            int valcorrect_questions = Convert.ToInt32(correct_questions.Value.ToString());

            if (correct_ans.Equals(your_ans.Value.ToString()))
            {
                valqno++;
                valmarks++;
                valsolved_questions++;
                valcorrect_questions++;

                qno.Value = valqno.ToString();
                marks.Value = valmarks.ToString();
                solved_questions.Value = valsolved_questions.ToString();
                correct_questions.Value = valcorrect_questions.ToString();

                load_question();
            }
            else
            {
                valqno++;
                valsolved_questions++;

                qno.Value = valqno.ToString();
                solved_questions.Value = valsolved_questions.ToString();

                load_question();
            }
            
                

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            int valqno = Convert.ToInt32(qno.Value.ToString());
            int valmarks = Convert.ToInt32(marks.Value.ToString());
            int valsolved_questions = Convert.ToInt32(solved_questions.Value.ToString());
            int valcorrect_questions = Convert.ToInt32(correct_questions.Value.ToString());

            try
            {
                cn.Close();
                cn.Open();
                Response.Write("<script type='text/javascript'> alert('" + Session["user_id"] + "'); </script> ");
                String query = "insert into result (user_id, user_name,course_name,solved_questions, total_questions, correct_questions, marks_obtained) values ('" + Session["user_id"] + "', '" + Session["user_name"] + "','" + Session["course_name"] + "','" + valsolved_questions + "','" + valqno + "','" + valcorrect_questions + "','" + valmarks + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();

                Response.Redirect("user_view_result.aspx");
                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }
    }
}