﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_courses
{
    public partial class allcourses2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_Click(object sender, EventArgs e)
        {
            Button b1 = (Button)sender; 
            DataListItem item = (DataListItem)b1.NamingContainer;

            HiddenField h1 = (HiddenField)item.FindControl("course_id");
            HiddenField h2 = (HiddenField)item.FindControl("course_name");
            HiddenField h3 = (HiddenField)item.FindControl("course_time");
            HiddenField h4 = (HiddenField)item.FindControl("course_price");
            HiddenField h5 = (HiddenField)item.FindControl("course_image");

            Session["course_id"] = h1.Value.ToString();
            Session["course_name"] = h2.Value.ToString();
            Session["course_time"] = h3.Value.ToString();
            Session["course_price"] = h4.Value.ToString();
            Session["course_image"] = h5.Value.ToString();

            Response.Redirect("cmain.aspx");

        }
    }
}