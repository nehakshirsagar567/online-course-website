﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using System.Data;

namespace Online_courses
{
    public partial class Rport_course_id : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;
        ReportDocument rprt = new ReportDocument();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            rprt.Load(Server.MapPath("~/rpt_Report_addcourses.rpt"));
            MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Online_courses; user=root; password=root");
            MySqlCommand cmd = new MySqlCommand("select * from addcourses where course_id = '" + TextBox1.Text + "'", cn);
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            rprt.SetDataSource(dt);
            CrystalReportViewer1.ReportSource = rprt;
            CrystalReportViewer1.DataBind();
   

        }
    }
}